package coe528.project;
//creates an abstract class called CustomerStatus
public abstract class CustomerStatus {
    
    public abstract void changeStatus(Customer c);
    public abstract String currentStatus();
    
}
